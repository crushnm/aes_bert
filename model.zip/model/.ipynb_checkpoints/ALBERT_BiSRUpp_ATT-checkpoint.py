import torch
import torch.nn as nn
from transformers import AutoModel
from transformers import BertModel
from model.BiSRUpp import BiSRUpp
from pathlib import Path

model_name = Path("bert-base-uncased").resolve()
# model_name = 'google-bert/bert-base-uncased'
# model_name = 'princeton-nlp/sup-simcse-bert-base-uncased'
# model_name = 'princeton-nlp/sup-simcse-roberta-large'

# if __name__ == '__main__':
#     model = ALBERT_BiSRUpp_ATT(sequence_length=512,num_classes = 11)
#     x = torch.randn((2, 8))
#     # 在0-7范围内，随机生成两个数，当做标签
#     y = torch.randint(0, 8, [2])
    
    

class ALBERT_BiSRUpp_ATT(nn.Module):
    def __init__(self, input_size=768, hidden_size=500, proj_size=512, num_layers=1, dropout=0.3, attn_dropout=0.1,
                 num_heads=8, bidirectional=True, layer_norm=True, normalize_after=True, highway_bias=-2.0,
                 attention_every_n_layers=2, rescale=True, nn_rnn_compatible_return=False,
                 proj_input_to_hidden_first=True, weight_c_init=1.0, linear_high=256, num_classes=2, use_cuda=False,
                 sequence_length=512):
        super(ALBERT_BiSRUpp_ATT, self).__init__()
        # 预训练模型
        self.sequence_length = sequence_length
        self.pre_trained = BertModel.from_pretrained(model_name)
        self.hidden_size = hidden_size
        self.attention_size = proj_size
        self.use_cuda = use_cuda
        # 双向内置注意力简单循环单元
        self.BiSRUpp = BiSRUpp(input_size=input_size,  # BiSRUpp
                               hidden_size=hidden_size,
                               proj_size=proj_size,
                               num_layers=num_layers,
                               dropout=dropout,
                               attn_dropout=attn_dropout,
                               num_heads=num_heads,
                               bidirectional=bidirectional,
                               layer_norm=layer_norm,
                               normalize_after=normalize_after,
                               highway_bias=highway_bias,
                               attention_every_n_layers=attention_every_n_layers,
                               rescale=rescale,
                               nn_rnn_compatible_return=nn_rnn_compatible_return,
                               proj_input_to_hidden_first=proj_input_to_hidden_first,
                               weight_c_init=weight_c_init)
        # 注意力机制
        self.bi = 1
        if bidirectional:
            self.bi = 2
        # 是否使用use_cuda
        if self.use_cuda:

            self.w_omega = nn.Parameter(torch.zeros(self.hidden_size * self.bi, self.attention_size).cuda())
            self.u_omega = nn.Parameter(torch.zeros(self.attention_size).cuda())
        else:
            w_omega = torch.zeros(self.hidden_size * self.bi, self.attention_size)
            nn.init.xavier_uniform_(w_omega)
            self.w_omega = nn.Parameter(w_omega)
            u_omega = torch.zeros(self.attention_size, 1)
            nn.init.xavier_uniform_(u_omega)
            self.u_omega = nn.Parameter(u_omega)
        # print("num_classes11:",num_classes)
        self.Linear = nn.Linear(self.hidden_size * self.bi, num_classes)

        self.ce_loss_fct = nn.CrossEntropyLoss()  # Log_softmax() + NLLLoss() 组成

    def attention_net(self, rnn_output):
        # 1、(sequence_length, batch_size, hidden_size * self.bi)
        output_reshape = torch.Tensor.reshape(rnn_output, [-1, self.hidden_size * self.bi])
        # 2、(sequence_length * batch_size, hidden_size*self.bi)
        attn_tanh = torch.tanh(torch.mm(output_reshape, self.w_omega))  # 维度转换到attention_size
        # 3、(sequence_length * batch_size, attention_size)

        attn_hidden_layer = torch.mm(attn_tanh, torch.Tensor.reshape(self.u_omega, [-1, 1]))
        # 4、(sequence_length * batch_size, 1)
        # 可以用Softmax函数替代
        # 分子
        exps = torch.Tensor.reshape(torch.exp(attn_hidden_layer), [-1, self.sequence_length])
        # 5、(batch_size, sequence_length)

        # 注意力得分(归一化)
        # 300个得分
        alphas = exps / torch.Tensor.reshape(torch.sum(exps, 1), [-1, 1])
        # 6、(batch_size, sequence_length)

        # 注意力得分
        alphas_reshape = torch.Tensor.reshape(alphas, [-1, self.sequence_length, 1])
        # 7、(batch_size, sequence_length, 1)

        state = rnn_output.permute(1, 0, 2)  # 维度转换
        # (batch_size, sequence_length, hidden_size*self.bi)
        # 加权求和
        attn_output = torch.sum(state * alphas_reshape, 1)
        # (batch_size, hidden_size*layer_size) 返回结果
        # 返回注意力计算结果
        return attn_output

    def forward(self, tokens, token_type_ids, attention_mask, labels):
        output = self.pre_trained(tokens,  attention_mask,token_type_ids,output_hidden_states=True, return_dict=True)
        # print("output1:",output.shape)
        # [batch_size, length, hidden_size]->[length, batch_size,hidden_size]
        # output = output[0][:, 1:]  # 除去CLS
        # output = output[0]
        output = output.last_hidden_state
        # print("output2:",output.shape)
        # 采用indices获取其中的句向量

        output = torch.transpose(output, 0, 1)
        # print("output3:",output.shape)

        # h:the output hidden state. shape: (length, batch_size,output_size) where
        #   output_size = hidden_size * num_direction
        output = self.BiSRUpp(output)[0]
        # print("output4:",output.shape)

        # 注意力计算
        att_output = self.attention_net(rnn_output=output)
        # print("att_output:",att_output.shape)
        # 输出层
        logits = self.Linear(att_output)
        # print("logits:",logits.shape) # [batch_size, num_classes]
        # print("labels:",labels)
        # print("labels:",labels.shape)
        loss = self.ce_loss_fct(logits, labels)  # 计算loss
        # print("loss:",loss)
       
        return loss, logits
