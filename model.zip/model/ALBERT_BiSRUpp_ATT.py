import torch
import torch.nn as nn
from transformers import AutoModel
from transformers import BertModel, LongformerModel, LongformerConfig
from model.xLSTM import MultiLevelxLSTM
from model.shallow_features import ShallowFeatureFusion
from model.topic_similarity import TopicSimilarityModule
from pathlib import Path

model_name = Path("bert-base-uncased").resolve()
# model_name = 'google-bert/bert-base-uncased'
# model_name = 'princeton-nlp/sup-simcse-bert-base-uncased'
# model_name = 'princeton-nlp/sup-simcse-roberta-large'

# if __name__ == '__main__':
#     model = ALBERT_BiSRUpp_ATT(sequence_length=512,num_classes = 11)
#     x = torch.randn((2, 8))
#     # 在0-7范围内，随机生成两个数，当做标签
#     y = torch.randint(0, 8, [2])
    
    

class ALBERT_BiSRUpp_ATT(nn.Module):
    def __init__(self, input_size=768, hidden_size=512, proj_size=512, num_layers=1, dropout=0.3, attn_dropout=0.1,
                 num_heads=8, bidirectional=True, layer_norm=True, normalize_after=True, highway_bias=-2.0,
                 attention_every_n_layers=2, rescale=True, nn_rnn_compatible_return=False,
                 proj_input_to_hidden_first=True, weight_c_init=1.0, linear_high=256, num_classes=2, use_cuda=False,
                 sequence_length=512, use_longformer=True, phrase_window_size=3, xlstm_cell_type='slstm',
                 use_shallow_features=True, use_topic_similarity=True, num_topics=8,
                 # 消融实验参数
                 use_scconv_mta=True,  # 是否使用SCConv+MTA（多层语义嵌入与注意力）
                pretrained_model='longformer',  # 预训练模型选择: 'longformer', 'bert', 'roberta'
                # 消融实验参数
                use_mta_w=True,  # 是否使用单词级注意力
                use_mta_p=True,  # 是否使用短语级注意力
                use_mta_s=True,  # 是否使用句子级注意力
                use_fine_grained_topic=True,  # 是否使用细粒度主题特征
                use_shallow_semantic=True,  # 是否使用浅层语义特征
                use_xlstm_w=True,  # 是否使用单词级xLSTM
                use_xlstm_p=True,  # 是否使用短语级xLSTM
                use_xlstm_s=True):  # 是否使用句子级xLSTM
        super(ALBERT_BiSRUpp_ATT, self).__init__()
        # 预训练模型
        self.sequence_length = sequence_length
        self.hidden_size = hidden_size
        self.attention_size = proj_size
        self.use_cuda = use_cuda
        self.use_longformer = use_longformer
        self.phrase_window_size = phrase_window_size
        self.use_shallow_features = use_shallow_features
        self.use_topic_similarity = use_topic_similarity
        self.num_topics = num_topics
        
        # 消融实验配置
        self.use_scconv_mta = use_scconv_mta  # 是否使用多层语义嵌入与注意力
        self.pretrained_model = pretrained_model.lower()
        
        # 新增消融实验配置
        self.use_mta_w = use_mta_w  # 是否使用单词级注意力
        self.use_mta_p = use_mta_p  # 是否使用短语级注意力
        self.use_mta_s = use_mta_s  # 是否使用句子级注意力
        self.use_fine_grained_topic = use_fine_grained_topic  # 是否使用细粒度主题特征
        self.use_shallow_semantic = use_shallow_semantic  # 是否使用浅层语义特征
        self.use_xlstm_w = use_xlstm_w  # 是否使用单词级xLSTM
        self.use_xlstm_p = use_xlstm_p  # 是否使用短语级xLSTM
        self.use_xlstm_s = use_xlstm_s  # 是否使用句子级xLSTM
        
        # 处理浅层语义特征的开关
        if not self.use_shallow_semantic:
            self.use_shallow_features = False
        
        # 根据消融实验配置选择预训练模型
        if self.pretrained_model == 'bert':
            print("使用 BERT 作为预训练模型")
            self.pre_trained = BertModel.from_pretrained(model_name)
            self.use_longformer = False
        elif self.pretrained_model == 'roberta':
            print("使用 RoBERTa 作为预训练模型")
            from transformers import RobertaModel
            try:
                self.pre_trained = RobertaModel.from_pretrained('roberta-base')
            except:
                # 如果加载失败，使用本地路径
                roberta_path = Path("roberta-base").resolve()
                self.pre_trained = RobertaModel.from_pretrained(roberta_path)
            self.use_longformer = False
        else:  # longformer (默认)
            print("使用 Longformer 作为预训练模型")
            self.pre_trained = BertModel.from_pretrained(model_name)
            # use_longformer 保持原值
        
        # Longformer层 - 用于提取长距离依赖的多层级语义
        # 只有在使用SCConv+MTA且使用longformer时才初始化这些模块
        if self.use_longformer and self.use_scconv_mta:
            # 方案：使用预训练的 Longformer，然后在 BERT 输出上应用
            # 创建一个轻量级的 Longformer 配置
            try:
                # 尝试加载预训练的 Longformer
                self.longformer = LongformerModel.from_pretrained('allenai/longformer-base-4096')
                print("成功加载预训练 Longformer 模型")
            except:
                # 如果加载失败，创建一个新的 Longformer
                print("创建新的 Longformer 配置")
                longformer_config = LongformerConfig(
                    vocab_size=30522,  # 与 BERT 相同
                    hidden_size=input_size,
                    num_hidden_layers=2,  # 使用较少的层数
                    num_attention_heads=num_heads,
                    intermediate_size=input_size * 4,
                    attention_window=[128, 128],  # 局部注意力窗口
                    attention_probs_dropout_prob=attn_dropout,
                    hidden_dropout_prob=dropout,
                    max_position_embeddings=4096  # 支持长文本
                )
                self.longformer = LongformerModel(longformer_config)
            
            # 添加一个投影层，将 BERT 输出映射到 Longformer 的嵌入空间
            self.bert_to_longformer = nn.Linear(input_size, input_size)
        
        # 浅层特征处理模块
        if self.use_shallow_features:
            self.shallow_norm = nn.BatchNorm1d(9)
            self.shallow_proj = nn.Sequential(
                nn.Linear(9, 64),
                nn.ReLU(),
                nn.Dropout(dropout),
                nn.Linear(64, 128)
            )
        
        # SCConv+MTA模块：多层语义嵌入与注意力
        if self.use_scconv_mta:
            # 短语级别提取 - 使用卷积捕获n-gram特征
            # 修复cuDNN问题：使用更稳定的配置
            self.phrase_conv = nn.Conv1d(
                in_channels=input_size,
                out_channels=input_size,
                kernel_size=phrase_window_size,
                padding=phrase_window_size // 2,
                groups=1,
                bias=True
            )
            
            # 句子级别提取 - 使用平均池化
            self.sentence_pooling = nn.AdaptiveAvgPool1d(1)
            
            # 多层级特征融合
            self.word_proj = nn.Linear(input_size, input_size)
            self.phrase_proj = nn.Linear(input_size, input_size)
            self.sentence_proj = nn.Linear(input_size, input_size)
            
            # 门控融合机制
            self.fusion_gate = nn.Sequential(
                nn.Linear(input_size * 3, input_size),
                nn.Sigmoid()
            )
            
            self.fusion_output = nn.Linear(input_size * 3, input_size)
            self.fusion_norm = nn.LayerNorm(input_size)
        else:
            # 不使用SCConv+MTA时，只需要简单的投影层
            self.simple_proj = nn.Linear(input_size, input_size)
        
        # Multi-level xLSTM - 替代BiSRUpp
        # 使用xLSTM分别处理word_level, phrase_level, sentence_level
        self.xlstm = MultiLevelxLSTM(
            input_size=input_size,
            hidden_size=hidden_size,
            cell_type=xlstm_cell_type,  # 'slstm' or 'mlstm'
            bidirectional=bidirectional,
            dropout=dropout,
            layer_norm=layer_norm
        )
        # 注意力机制
        self.bi = 1
        if bidirectional:
            self.bi = 2
        # 是否使用use_cuda
        
        # 多层级注意力机制（MTA）参数
        if self.use_cuda:
            # 单词级注意力
            self.w_omega_word = nn.Parameter(torch.zeros(self.hidden_size * self.bi, self.attention_size).cuda())
            self.u_omega_word = nn.Parameter(torch.zeros(self.attention_size).cuda())
            # 短语级注意力
            self.w_omega_phrase = nn.Parameter(torch.zeros(self.hidden_size * self.bi, self.attention_size).cuda())
            self.u_omega_phrase = nn.Parameter(torch.zeros(self.attention_size).cuda())
            # 句子级注意力
            self.w_omega_sentence = nn.Parameter(torch.zeros(self.hidden_size * self.bi, self.attention_size).cuda())
            self.u_omega_sentence = nn.Parameter(torch.zeros(self.attention_size).cuda())
        else:
            # 单词级注意力
            w_omega_word = torch.zeros(self.hidden_size * self.bi, self.attention_size)
            nn.init.xavier_uniform_(w_omega_word)
            self.w_omega_word = nn.Parameter(w_omega_word)
            u_omega_word = torch.zeros(self.attention_size, 1)
            nn.init.xavier_uniform_(u_omega_word)
            self.u_omega_word = nn.Parameter(u_omega_word)
            
            # 短语级注意力
            w_omega_phrase = torch.zeros(self.hidden_size * self.bi, self.attention_size)
            nn.init.xavier_uniform_(w_omega_phrase)
            self.w_omega_phrase = nn.Parameter(w_omega_phrase)
            u_omega_phrase = torch.zeros(self.attention_size, 1)
            nn.init.xavier_uniform_(u_omega_phrase)
            self.u_omega_phrase = nn.Parameter(u_omega_phrase)
            
            # 句子级注意力
            w_omega_sentence = torch.zeros(self.hidden_size * self.bi, self.attention_size)
            nn.init.xavier_uniform_(w_omega_sentence)
            self.w_omega_sentence = nn.Parameter(w_omega_sentence)
            u_omega_sentence = torch.zeros(self.attention_size, 1)
            nn.init.xavier_uniform_(u_omega_sentence)
            self.u_omega_sentence = nn.Parameter(u_omega_sentence)
        
        # 主题相似度模块
        if self.use_topic_similarity:
            self.topic_similarity = TopicSimilarityModule(
                hidden_size=input_size,
                num_topics=num_topics,
                use_learnable_topics=True,
                similarity_type='cosine',
                dropout=dropout
            )
            # 主题相似度特征维度
            if self.use_scconv_mta:
                topic_feature_dim = 3  # word, phrase, sentence各一个
            else:
                topic_feature_dim = 1  # 只有一个整体特征
        else:
            topic_feature_dim = 0
        
        # 计算最终特征维度
        if self.use_scconv_mta:
            # 使用多层语义：word + phrase + sentence
            xlstm_output_dim = self.hidden_size * self.bi * 3
        else:
            # 不使用多层语义：只有单一输出
            xlstm_output_dim = self.hidden_size * self.bi
        
        shallow_feature_dim = 128 if self.use_shallow_features else 0
        final_feature_dim = xlstm_output_dim + shallow_feature_dim + topic_feature_dim
        
        self.Linear = nn.Linear(final_feature_dim, num_classes)

        self.ce_loss_fct = nn.CrossEntropyLoss()  # Log_softmax() + NLLLoss() 组成

    def attention_net(self, rnn_output, w_omega, u_omega):
        # 1、(sequence_length, batch_size, hidden_size * self.bi)
        output_reshape = torch.Tensor.reshape(rnn_output, [-1, self.hidden_size * self.bi])
        # 2、(sequence_length * batch_size, hidden_size*self.bi)
        attn_tanh = torch.tanh(torch.mm(output_reshape, w_omega))  # 维度转换到attention_size
        # 3、(sequence_length * batch_size, attention_size)

        attn_hidden_layer = torch.mm(attn_tanh, torch.Tensor.reshape(u_omega, [-1, 1]))
        # 4、(sequence_length * batch_size, 1)
        # 可以用Softmax函数替代
        # 分子
        exps = torch.Tensor.reshape(torch.exp(attn_hidden_layer), [-1, self.sequence_length])
        # 5、(batch_size, sequence_length)

        # 注意力得分(归一化)
        # 300个得分
        alphas = exps / torch.Tensor.reshape(torch.sum(exps, 1), [-1, 1])
        # 6、(batch_size, sequence_length)

        # 注意力得分
        alphas_reshape = torch.Tensor.reshape(alphas, [-1, self.sequence_length, 1])
        # 7、(batch_size, sequence_length, 1)

        state = rnn_output.permute(1, 0, 2)  # 维度转换
        # (batch_size, sequence_length, hidden_size*self.bi)
        # 加权求和
        attn_output = torch.sum(state * alphas_reshape, 1)
        # (batch_size, hidden_size*layer_size) 返回结果
        # 返回注意力计算结果
        return attn_output

    def extract_multilevel_embeddings(self, word_embeddings):
        """
        提取多层级语义嵌入：单词级、短语级、句子级
        
        Args:
            word_embeddings: [batch_size, seq_len, hidden_size]
        
        Returns:
            fused_embeddings: [batch_size, seq_len, hidden_size]
        """
        batch_size, seq_len, hidden_size = word_embeddings.shape
        
        # 1. 单词级别嵌入 (Word-level)
        word_level = self.word_proj(word_embeddings)  # [batch_size, seq_len, hidden_size]
        
        # 2. 短语级别嵌入 (Phrase-level) - 使用卷积提取局部n-gram特征
        # 转换维度以适配Conv1d: [batch_size, hidden_size, seq_len]
        word_embeddings_t = word_embeddings.transpose(1, 2).contiguous()
        
        try:
            # 尝试使用卷积
            phrase_level = self.phrase_conv(word_embeddings_t)  # [batch_size, hidden_size, seq_len]
        except RuntimeError as e:
            # 如果cuDNN出错，使用备用方案：平均池化
            print(f"卷积操作失败，使用备用方案: {e}")
            # 使用简单的滑动窗口平均
            kernel_size = self.phrase_window_size
            padding = kernel_size // 2
            phrase_level = torch.nn.functional.avg_pool1d(
                word_embeddings_t, 
                kernel_size=kernel_size, 
                stride=1, 
                padding=padding
            )
            # 确保输出长度与输入相同
            if phrase_level.size(2) != seq_len:
                phrase_level = torch.nn.functional.interpolate(
                    phrase_level, 
                    size=seq_len, 
                    mode='linear', 
                    align_corners=False
                )
        
        phrase_level = phrase_level.transpose(1, 2)  # [batch_size, seq_len, hidden_size]
        phrase_level = self.phrase_proj(phrase_level)
        
        # 3. 句子级别嵌入 (Sentence-level) - 全局语义信息
        # 使用平均池化获取句子级表示，然后广播到每个位置
        sentence_repr = torch.mean(word_embeddings, dim=1, keepdim=True)  # [batch_size, 1, hidden_size]
        sentence_level = self.sentence_proj(sentence_repr)
        sentence_level = sentence_level.expand(-1, seq_len, -1)  # [batch_size, seq_len, hidden_size]
        
        
        return word_level, phrase_level, sentence_level

    def forward(self, tokens, token_type_ids, attention_mask, labels, shallow_features=None, topic_ids=None):
        # 1. 预训练模型提取基础特征
        if self.pretrained_model == 'roberta':
            # RoBERTa 不使用 token_type_ids
            bert_output = self.pre_trained(tokens, attention_mask, 
                                          output_hidden_states=True, return_dict=True)
            output = bert_output.last_hidden_state  # [batch_size, seq_len, hidden_size]
        elif self.pretrained_model == 'bert':
            # BERT 和 Longformer 使用 token_type_ids
            bert_output = self.pre_trained(tokens, attention_mask, token_type_ids, 
                                          output_hidden_states=True, return_dict=True)
            output = bert_output.last_hidden_state  # [batch_size, seq_len, hidden_size]
        
        # 2. 根据配置选择是否使用Longformer和多层语义嵌入
        if self.use_scconv_mta:
            # 使用完整的SCConv+MTA模块
            if self.use_longformer:
                # Longformer层 - 提取长距离依赖和多层级语义
                batch_size, seq_len = tokens.shape
                global_attention_mask = torch.zeros_like(tokens, dtype=torch.long)
                global_attention_mask[:, 0] = 1  # [CLS] token 使用全局注意力
                
                # 使用 Longformer 处理
                try:
                    longformer_output = self.longformer(
                        input_ids=tokens,
                        attention_mask=attention_mask,
                        token_type_ids=token_type_ids,
                        global_attention_mask=global_attention_mask,
                        return_dict=True
                    )
                    # 使用 Longformer 的输出
                    output = longformer_output.last_hidden_state  # [batch_size, seq_len, hidden_size]
                except Exception as e:
                    # 如果 Longformer 出错，使用 BERT 输出并通过投影层
                    print(f"Longformer 处理出错，使用 BERT 输出: {e}")
                    output = self.bert_to_longformer(output)
            
            word_level, phrase_level, sentence_level = self.extract_multilevel_embeddings(output)
            
            word_level = torch.transpose(word_level, 0, 1)
            phrase_level = torch.transpose(phrase_level, 0, 1)
            sentence_level = torch.transpose(sentence_level, 0, 1)
            
            # 处理xLSTM的消融实验
            if self.use_xlstm_w and self.use_xlstm_p and self.use_xlstm_s:
                # 使用完整的xLSTM
                word_out, phrase_out, sentence_out = self.xlstm(word_level, phrase_level, sentence_level)
            else:
                # 根据配置选择xLSTM输入
                xlstm_input_w = word_level if self.use_xlstm_w else torch.zeros_like(word_level)
                xlstm_input_p = phrase_level if self.use_xlstm_p else torch.zeros_like(phrase_level)
                xlstm_input_s = sentence_level if self.use_xlstm_s else torch.zeros_like(sentence_level)
                
                word_out, phrase_out, sentence_out = self.xlstm(xlstm_input_w, xlstm_input_p, xlstm_input_s)
            
            # 多层级注意力机制（MTA）
            # 单词级注意力
            if self.use_mta_w:
                word_out = self.attention_net(word_out, self.w_omega_word, self.u_omega_word)
            else:
                word_out = torch.mean(word_out, dim=0)  # 使用平均池化替代
            
            # 短语级注意力
            if self.use_mta_p:
                phrase_out = self.attention_net(phrase_out, self.w_omega_phrase, self.u_omega_phrase)
            else:
                phrase_out = torch.mean(phrase_out, dim=0)  # 使用平均池化替代
            
            # 句子级注意力
            if self.use_mta_s:
                sentence_out = self.attention_net(sentence_out, self.w_omega_sentence, self.u_omega_sentence)
            else:
                sentence_out = torch.mean(sentence_out, dim=0)  # 使用平均池化替代
            
            if self.use_topic_similarity:
                # 获取[CLS]位置的句子级表示
                sentence_cls = output[:, 0, :]  # [batch_size, hidden_size]
                
                if self.use_fine_grained_topic:
                    # 计算细粒度主题特征
                    word_level_for_sim = torch.transpose(word_level, 0, 1)
                    phrase_level_for_sim = torch.transpose(phrase_level, 0, 1)
                    
                    topic_similarity_features = self.topic_similarity(
                        word_embeddings=word_level_for_sim,
                        phrase_embeddings=phrase_level_for_sim,
                        sentence_embeddings=sentence_cls,
                        topic_ids=topic_ids
                    )  # [batch_size, 3]
                else:
                    # 只计算句子级主题特征
                    topic_similarity_features = self.topic_similarity(
                        word_embeddings=None,
                        phrase_embeddings=None,
                        sentence_embeddings=sentence_cls,
                        topic_ids=topic_ids
                    )  # [batch_size, 1]
            
            # 7. 特征拼接（多层级）
            feature_list = [word_out, phrase_out, sentence_out]
            
        else:
            # W/o SCConv+MTA: 不使用多层语义嵌入与注意力
            # 只使用单一的特征提取路径
            
            # 简单投影
            output = self.simple_proj(output)
            
            output = torch.transpose(output, 0, 1)  # [seq_len, batch_size, hidden_size]
            
            single_out = self.xlstm(output, output, output)[0]  # 只取第一个输出
            
            # 使用注意力机制聚合特征
            single_out = self.attention_net(single_out, self.w_omega_word, self.u_omega_word)  # [batch_size, hidden_size * bi]
            
            if self.use_topic_similarity:
                # 获取[CLS]位置的句子级表示
                output_transposed = torch.transpose(output, 0, 1)  # [batch_size, seq_len, hidden_size]
                sentence_cls = output_transposed[:, 0, :]  # [batch_size, hidden_size]
                
                # 只计算句子级别的主题相似度
                topic_similarity_features = self.topic_similarity(
                    word_embeddings=output_transposed,
                    phrase_embeddings=output_transposed,
                    sentence_embeddings=sentence_cls,
                    topic_ids=topic_ids
                )  # [batch_size, 3]
                # 只取句子级别的相似度
                topic_similarity_features = topic_similarity_features[:, 2:3]  # [batch_size, 1]
            
            feature_list = [single_out]
        
        if self.use_shallow_features and shallow_features is not None:
            shallow_norm = self.shallow_norm(shallow_features)
            shallow_proj = self.shallow_proj(shallow_norm)
            feature_list.append(shallow_proj)
        
        if self.use_topic_similarity:
            feature_list.append(topic_similarity_features)
        
        att_output = torch.cat(feature_list, dim=-1)
        
        logits = self.Linear(att_output)  # [batch_size, num_classes]
        
        loss = self.ce_loss_fct(logits, labels)
       
        return loss, logits
