import torch
import torch.nn as nn
import torch.nn.functional as F
import math


class sLSTMCell(nn.Module):
    """
    Scalar LSTM Cell with exponential gating
    """
    def __init__(self, input_size, hidden_size):
        super(sLSTMCell, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        
        # Input gate
        self.W_i = nn.Linear(input_size, hidden_size)
        self.U_i = nn.Linear(hidden_size, hidden_size)
        
        # Forget gate
        self.W_f = nn.Linear(input_size, hidden_size)
        self.U_f = nn.Linear(hidden_size, hidden_size)
        
        # Cell gate
        self.W_c = nn.Linear(input_size, hidden_size)
        self.U_c = nn.Linear(hidden_size, hidden_size)
        
        # Output gate
        self.W_o = nn.Linear(input_size, hidden_size)
        self.U_o = nn.Linear(hidden_size, hidden_size)
        
        self._init_weights()
    
    def _init_weights(self):
        for name, param in self.named_parameters():
            if 'weight' in name:
                nn.init.xavier_uniform_(param)
            elif 'bias' in name:
                nn.init.zeros_(param)
    
    def forward(self, x, states):
        """
        Args:
            x: [batch_size, input_size]
            states: (h, c, n, m) where
                h: [batch_size, hidden_size]
                c: [batch_size, hidden_size]
                n: [batch_size, hidden_size] - normalizer
                m: [batch_size, hidden_size] - stabilizer
        """
        h_prev, c_prev, n_prev, m_prev = states
        
        # Exponential gates
        i_tilde = self.W_i(x) + self.U_i(h_prev)
        f_tilde = self.W_f(x) + self.U_f(h_prev)
        
        # Stabilizer update
        m_t = torch.max(f_tilde + m_prev, i_tilde)
        
        # Exponential gating with stabilization
        i_t = torch.exp(i_tilde - m_t)
        f_t = torch.exp(f_tilde + m_prev - m_t)
        
        # Cell input
        c_tilde = self.W_c(x) + self.U_c(h_prev)
        c_tilde = torch.tanh(c_tilde)
        
        # Cell state update
        c_t = f_t * c_prev + i_t * c_tilde
        
        # Normalizer update
        n_t = f_t * n_prev + i_t
        
        # Normalized cell state
        c_t_norm = c_t / (n_t + 1e-6)
        
        # Output gate
        o_tilde = self.W_o(x) + self.U_o(h_prev)
        o_t = torch.sigmoid(o_tilde)
        
        # Hidden state
        h_t = o_t * torch.tanh(c_t_norm)
        
        return h_t, (h_t, c_t, n_t, m_t)


class mLSTMCell(nn.Module):
    """
    Matrix LSTM Cell with covariance update rule
    """
    def __init__(self, input_size, hidden_size, head_size=None):
        super(mLSTMCell, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.head_size = head_size if head_size else hidden_size
        
        # Query, Key, Value projections
        self.W_q = nn.Linear(input_size, hidden_size)
        self.W_k = nn.Linear(input_size, hidden_size)
        self.W_v = nn.Linear(input_size, hidden_size)
        
        # Input and forget gates
        self.W_i = nn.Linear(input_size, hidden_size)
        self.W_f = nn.Linear(input_size, hidden_size)
        
        # Output gate
        self.W_o = nn.Linear(input_size, hidden_size)
        
        self._init_weights()
    
    def _init_weights(self):
        for name, param in self.named_parameters():
            if 'weight' in name:
                nn.init.xavier_uniform_(param)
            elif 'bias' in name:
                nn.init.zeros_(param)
    
    def forward(self, x, states):
        """
        Args:
            x: [batch_size, input_size]
            states: (C, n, m) where
                C: [batch_size, hidden_size, hidden_size] - matrix memory
                n: [batch_size, hidden_size] - normalizer
                m: [batch_size, 1] - stabilizer
        """
        C_prev, n_prev, m_prev = states
        batch_size = x.size(0)
        
        # Compute query, key, value
        q = self.W_q(x)  # [batch_size, hidden_size]
        k = self.W_k(x)  # [batch_size, hidden_size]
        v = self.W_v(x)  # [batch_size, hidden_size]
        
        # Exponential gates
        i_tilde = self.W_i(x)  # [batch_size, hidden_size]
        f_tilde = self.W_f(x)  # [batch_size, hidden_size]
        
        # Stabilizer update
        m_t = torch.max(torch.max(f_tilde, dim=1, keepdim=True)[0] + m_prev,
                       torch.max(i_tilde, dim=1, keepdim=True)[0])
        
        # Exponential gating
        i_t = torch.exp(i_tilde - m_t)  # [batch_size, hidden_size]
        f_t = torch.exp(f_tilde + m_prev - m_t)  # [batch_size, hidden_size]
        
        # Matrix memory update (covariance form)
        # C_t = f_t * C_prev + i_t * (v ⊗ k^T)
        f_t_expanded = f_t.unsqueeze(2)  # [batch_size, hidden_size, 1]
        C_t = f_t_expanded * C_prev + i_t.unsqueeze(2) * (v.unsqueeze(2) @ k.unsqueeze(1))
        
        # Normalizer update
        n_t = f_t * n_prev + i_t * k
        
        # Retrieve from memory
        # h_tilde = C_t @ q / (n_t^T @ q + eps)
        numerator = torch.bmm(C_t, q.unsqueeze(2)).squeeze(2)  # [batch_size, hidden_size]
        denominator = (n_t * q).sum(dim=1, keepdim=True) + 1e-6  # [batch_size, 1]
        h_tilde = numerator / denominator
        
        # Output gate
        o_t = torch.sigmoid(self.W_o(x))
        
        # Hidden state
        h_t = o_t * h_tilde
        
        return h_t, (C_t, n_t, m_t)


class xLSTMLayer(nn.Module):
    """
    xLSTM Layer that can use either sLSTM or mLSTM
    """
    def __init__(self, input_size, hidden_size, cell_type='slstm', bidirectional=False):
        super(xLSTMLayer, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.cell_type = cell_type
        self.bidirectional = bidirectional
        
        if cell_type == 'slstm':
            self.cell_forward = sLSTMCell(input_size, hidden_size)
            if bidirectional:
                self.cell_backward = sLSTMCell(input_size, hidden_size)
        elif cell_type == 'mlstm':
            self.cell_forward = mLSTMCell(input_size, hidden_size)
            if bidirectional:
                self.cell_backward = mLSTMCell(input_size, hidden_size)
        else:
            raise ValueError(f"Unknown cell_type: {cell_type}")
    
    def _init_states(self, batch_size, device):
        """Initialize hidden states"""
        if self.cell_type == 'slstm':
            h = torch.zeros(batch_size, self.hidden_size, device=device)
            c = torch.zeros(batch_size, self.hidden_size, device=device)
            n = torch.zeros(batch_size, self.hidden_size, device=device)
            m = torch.zeros(batch_size, self.hidden_size, device=device)
            return (h, c, n, m)
        else:  # mlstm
            C = torch.zeros(batch_size, self.hidden_size, self.hidden_size, device=device)
            n = torch.zeros(batch_size, self.hidden_size, device=device)
            m = torch.zeros(batch_size, 1, device=device)
            return (C, n, m)
    
    def forward(self, x):
        """
        Args:
            x: [seq_len, batch_size, input_size] or [batch_size, seq_len, input_size]
        Returns:
            output: [seq_len, batch_size, hidden_size * num_directions]
        """
        # Handle both input formats
        if x.dim() == 3 and x.size(0) != x.size(1):
            # Assume [batch_size, seq_len, input_size], convert to [seq_len, batch_size, input_size]
            if x.size(1) > x.size(0):
                x = x.transpose(0, 1)
        
        seq_len, batch_size, _ = x.size()
        device = x.device
        
        # Forward direction
        states_forward = self._init_states(batch_size, device)
        outputs_forward = []
        
        for t in range(seq_len):
            h_t, states_forward = self.cell_forward(x[t], states_forward)
            outputs_forward.append(h_t)
        
        outputs_forward = torch.stack(outputs_forward, dim=0)  # [seq_len, batch_size, hidden_size]
        
        if self.bidirectional:
            # Backward direction
            states_backward = self._init_states(batch_size, device)
            outputs_backward = []
            
            for t in range(seq_len - 1, -1, -1):
                h_t, states_backward = self.cell_backward(x[t], states_backward)
                outputs_backward.append(h_t)
            
            outputs_backward = torch.stack(outputs_backward[::-1], dim=0)  # [seq_len, batch_size, hidden_size]
            
            # Concatenate forward and backward
            output = torch.cat([outputs_forward, outputs_backward], dim=2)  # [seq_len, batch_size, hidden_size*2]
        else:
            output = outputs_forward
        
        return output, None  # Return None for compatibility with RNN interface


class MultiLevelxLSTM(nn.Module):
    """
    Multi-level xLSTM for word, phrase, and sentence level processing
    """
    def __init__(self, input_size, hidden_size, cell_type='slstm', bidirectional=True, 
                 dropout=0.3, layer_norm=True):
        super(MultiLevelxLSTM, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.bidirectional = bidirectional
        self.num_directions = 2 if bidirectional else 1
        
        # Three separate xLSTM layers for different levels
        self.word_xlstm = xLSTMLayer(input_size, hidden_size, cell_type, bidirectional)
        self.phrase_xlstm = xLSTMLayer(input_size, hidden_size, cell_type, bidirectional)
        self.sentence_xlstm = xLSTMLayer(input_size, hidden_size, cell_type, bidirectional)
        
        # Layer normalization
        self.layer_norm = layer_norm
        if layer_norm:
            self.word_norm = nn.LayerNorm(hidden_size * self.num_directions)
            self.phrase_norm = nn.LayerNorm(hidden_size * self.num_directions)
            self.sentence_norm = nn.LayerNorm(hidden_size * self.num_directions)
        
        # Dropout
        self.dropout = nn.Dropout(dropout)
        
        # Fusion layer to combine three levels
        self.fusion = nn.Linear(hidden_size * self.num_directions * 3, hidden_size * self.num_directions)
        self.fusion_norm = nn.LayerNorm(hidden_size * self.num_directions)
    
    def forward(self, word_level, phrase_level, sentence_level):
        """
        Args:
            word_level: [seq_len, batch_size, input_size] or [batch_size, seq_len, input_size]
            phrase_level: [seq_len, batch_size, input_size] or [batch_size, seq_len, input_size]
            sentence_level: [seq_len, batch_size, input_size] or [batch_size, seq_len, input_size]
        Returns:
            output: [seq_len, batch_size, hidden_size * num_directions]
        """
        # Process each level with xLSTM
        word_out, _ = self.word_xlstm(word_level)
        phrase_out, _ = self.phrase_xlstm(phrase_level)
        sentence_out, _ = self.sentence_xlstm(sentence_level)
        
        # Apply layer normalization
        if self.layer_norm:
            word_out = self.word_norm(word_out)
            phrase_out = self.phrase_norm(phrase_out)
            sentence_out = self.sentence_norm(sentence_out)
        
        # Apply dropout
        word_out = self.dropout(word_out)
        phrase_out = self.dropout(phrase_out)
        sentence_out = self.dropout(sentence_out)
        
        # Concatenate all levels
        combined = torch.cat([word_out, phrase_out, sentence_out], dim=-1)
        
        # Fusion
        output = self.fusion(combined)
        output = self.fusion_norm(output)
        
        return word_out, phrase_out, sentence_out  # Return None for compatibility
